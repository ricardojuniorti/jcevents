@extends('layouts.main')

    @section('title', 'Contato')
   
    @section('content')

        <h1>Contato:</h1>

    @endsection
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonte do Google -->
        <link href="https://fonts.googleapis.com/css2?family=Roboto" rel="stylesheet">

        <!-- CSS Bootstrap -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

        <!-- CSS da aplicação -->
        <link rel="stylesheet" href="/css/styles.css">
        <script src="/js/scripts.js"></script>
    </head>
    <body>
      <header> 
        <nav class="navbar-expand-lg navbar-light" id="nav">
        <a href="/" id="logo"><img src="/img/jcevents.png" alt="JC Events"></a>
          <button aria-label="Abrir Menu" id="btn-mobile" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
            <span id="hamburger"></span>
          </button>
          <ul id="menu" role="menu">
            <li>
                <a href="/" class="nav-link">Eventos</a>
            </li>
            <li><a href="/events/create">Criar Evento agora</a></li>
            <?php if(auth()->guard()->check()): ?>
            <li><a href="/dashboard">Meus Eventos</a></li>
            <li>
              <form action="/logout" method="POST">
                <?php echo csrf_field(); ?>
                <a href="/logout" class="nav-link" onclick="event.preventDefault();this.closest('form').submit();">Sair</a>
              </form></li>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
              <li>
                <a href="/login" class="nav-link">Entrar</a>
              </li>
              <li>
                <a href="/register" class="nav-link">Cadastrar</a>
              </li>
              <?php endif; ?>
          </ul>
        </nav>
      </header>
      <script src="/js/menu_mobile.js"></script>
      <main>
        <div class="container-fluid">
          <div class="row">
            <?php if(session('msg')): ?>
              <p class="msg"><?php echo e(session('msg')); ?></p>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>
      </main>
      <footer>
        <p>JC Events &copy; 2022</p>
      </footer>
      <script src="https://unpkg.com/ionicons@5.1.2/dist/ionicons.js"></script>
    </body>
</html>
<?php /**PATH E:\laragon\www\TCC\jcevents\resources\views/layouts/main.blade.php ENDPATH**/ ?>
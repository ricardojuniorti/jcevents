@extends('layouts.main')

@section('title', $event->title)

@section('content')

  <div class="col-md-10 offset-md-1">
    <div class="row">
      <div id="image-container" class="col-md-6">
        <img src="/img/events/{{ $event->image }}" class="img-fluid" alt="{{ $event->title }}">
      </div>
      <div id="info-container" class="col-md-6">
        <h1>{{ $event->title }}</h1>
        <p class="event-city"><ion-icon name="location-outline"></ion-icon> Local: {{ $event->city }}</p>
        <p class="events-date"><ion-icon name="time-outline"></ion-icon> Data do Evento: {{ date('d/m/Y',  strtotime($event->date))   }}</p>
        <p class="events-date"><ion-icon name="time-outline"></ion-icon>Horario de início: {{ $event->hora_inicio }}</p>
        <p class="events-date"><ion-icon name="time-outline"></ion-icon> Horário de término: {{ $event->hora_fim }}</p>
        <p class="events-participants"><ion-icon name="people-outline"></ion-icon> {{ count($event->users) }} Participantes até o momento</p>
        <p class="event-owner"><ion-icon name="star-outline"></ion-icon> Responsável pelo evento: {{ $eventOwner['name'] }}</p>
        @if(!$hasUserJoined)
          <form action="/events/join/{{ $event->id }}" method="POST">
            @csrf
            <a href="/events/join/{{ $event->id }}" 
              class="btn btn-primary" 
              id="event-submit"
              onclick="event.preventDefault();
              this.closest('form').submit();">
              Confirmar Presença
            </a>
          </form>
        @else
          <p class="already-joined-msg">Você já está participando deste evento!</p>
        @endif
        <h3>O evento conta com:</h3>
        <ul id="items-list">
        @if($items_events)
          @foreach($items_events as $item)
            <li><ion-icon name="play-outline"></ion-icon> <span>{{ $item->description }}</span></li>
          @endforeach
        @endif
        </ul>
      </div>
      <div class="col-md-12" id="description-container">
        <h3>Sobre o evento:</h3>
        <p class="event-description">{{ $event->description }}</p>
      </div>
    </div>
  </div>

@endsection
<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Items extends Model
{
    use HasFactory;

    protected $casts = [
        'items' => 'array'
    ];

    protected $dates = ['date'];

    protected $guarded = [];


    public function recuperarItemsEvents() {

        $registro = DB::table('items')
        ->select('id','description')
        ->orderByRaw('items.description ASC')
        ->get();

        if ($registro != null){
            return $registro;
        }
        else{
            return null;
        }

    }

    public function recuperarItemsEventsPeloId($id = null) {

        if($id != null){

            $registro = DB::table('items')
                    ->where('events_items.events_id', $id)
                    ->select('items.id as id','items.description as description')
                    ->orderByRaw('items.description ASC')
                    ->Join('events_items', 'events_items.items_id', '=', 'items.id')
                    ->get();
        
            return $registro;

        }

        else{
            return null;
        }

    }

}